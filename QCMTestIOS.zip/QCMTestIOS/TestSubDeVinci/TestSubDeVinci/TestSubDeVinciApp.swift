//
//  TestSubDeVinciApp.swift
//  TestSubDeVinci
//
//  Created by Guillaume on 16/04/2024.
//

import SwiftUI

@main
struct TestSubDeVinciApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
